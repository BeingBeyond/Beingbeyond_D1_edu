import re
import time
import math
import threading
from dataclasses import dataclass
from typing import List, Optional, Tuple

import serial
import matplotlib.pyplot as plt


@dataclass
class GloveConfig:
    port: str = "/dev/ttyACM0"
    baudrate: int = 115200
    timeout: float = 0.01
    debug_print: bool = False

    use_auto_calib: bool = True
    max_samples: int = 200
    min_samples: int = 30
    stable_window: int = 20
    stable_eps_deg: float = 0.5

    offset_deg: List[float] = None  # angle_at_1 = angle_at_0 + offset_deg
    channel_labels: List[str] = None


class GloveReader:
    ANGLE_RE = re.compile(r"=\s*([-+]?\d+(?:\.\d+)?)")

    def __init__(self, cfg: GloveConfig):
        self.cfg = cfg

        if self.cfg.offset_deg is None:
            self.cfg.offset_deg = [40.0, -70.0, 60.0, 60.0, 60.0, 60.0]
        if self.cfg.channel_labels is None:
            self.cfg.channel_labels = ["p0_50", "p0_51", "p0_52", "p1_50", "p1_51", "p1_52"]

        self._ser: Optional[serial.Serial] = None
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None

        self._lock = threading.Lock()
        self._angles_deg: List[float] = [0.0] * 6
        self._norm_values: List[float] = [0.0] * 6
        self._latest_line: str = ""

        self._deg_at_0: List[float] = [0.0] * 6
        self._deg_at_1: List[float] = [d + off for d, off in zip(self._deg_at_0, self.cfg.offset_deg)]

        self._open_serial()

        if self.cfg.use_auto_calib:
            ok = self._auto_calibrate()
            if not ok:
                raise RuntimeError(
                    "[GloveReader] Auto calibration failed. Keep glove still at ZERO pose and retry."
                )

        self._start_thread()

    def _open_serial(self) -> None:
        try:
            self._ser = serial.Serial(
                port=self.cfg.port,
                baudrate=self.cfg.baudrate,
                timeout=self.cfg.timeout,
            )
            print(f"[GloveReader] Serial opened: {self.cfg.port}")
        except serial.SerialException as e:
            raise RuntimeError(f"[GloveReader] Failed to open serial: {e}") from e

    def close(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
        if self._ser is not None:
            try:
                self._ser.close()
            except Exception:
                pass
        print("[GloveReader] Serial closed.")

    def get_angles_deg(self) -> List[float]:
        with self._lock:
            return list(self._angles_deg)

    def get_norm_values(self) -> List[float]:
        with self._lock:
            return list(self._norm_values)

    def get_latest_line(self) -> str:
        with self._lock:
            return self._latest_line

    def _parse_angles_line(self, line: str) -> Optional[List[float]]:
        if "ANGLES:" not in line:
            return None
        matches = self.ANGLE_RE.findall(line)
        if len(matches) != 6:
            if self.cfg.debug_print:
                print("  [WARN] Not 6 numbers, parsed =", matches)
            return None
        try:
            angles = [float(x) for x in matches]
        except ValueError:
            return None
        return angles

    def _auto_calibrate(self) -> bool:
        if self._ser is None:
            return False

        print("[GloveReader] AUTO calibration: keep glove at ZERO pose...")

        samples: List[List[float]] = []
        stabilized = False

        while len(samples) < self.cfg.max_samples:
            try:
                line_bytes = self._ser.readline()
            except serial.SerialException:
                return False

            if not line_bytes:
                continue

            line = line_bytes.decode("utf-8", errors="ignore").strip()
            angles = self._parse_angles_line(line)
            if angles is None:
                continue

            samples.append(angles)

            if len(samples) >= self.cfg.stable_window:
                window = samples[-self.cfg.stable_window:]
                ranges = []
                for ch in range(6):
                    vals = [s[ch] for s in window]
                    ranges.append(max(vals) - min(vals))

                if self.cfg.debug_print:
                    print("[Calib] ranges(deg):", ["%.3f" % r for r in ranges])

                if max(ranges) < self.cfg.stable_eps_deg and len(samples) >= self.cfg.min_samples:
                    stabilized = True
                    break

        if not samples or not stabilized:
            return False

        used = samples[-self.cfg.stable_window:] if len(samples) >= self.cfg.stable_window else samples
        deg_at_0 = []
        for ch in range(6):
            vals = [s[ch] for s in used]
            deg_at_0.append(sum(vals) / len(vals))

        deg_at_1 = [deg_at_0[i] + self.cfg.offset_deg[i] for i in range(6)]

        with self._lock:
            self._deg_at_0 = deg_at_0
            self._deg_at_1 = deg_at_1

        print("[GloveReader] calibration finished.")
        if self.cfg.debug_print:
            print("  deg_at_0:", ["%.2f" % a for a in deg_at_0])
            print("  deg_at_1:", ["%.2f" % a for a in deg_at_1])

        return True

    def _map_angle_to_norm(self, angle_deg: float, idx: int) -> float:
        a0 = self._deg_at_0[idx]
        a1 = self._deg_at_1[idx]
        if abs(a1 - a0) < 1e-6:
            return 0.0
        t = (angle_deg - a0) / (a1 - a0)
        if t < 0.0:
            t = 0.0
        elif t > 1.0:
            t = 1.0
        return t

    def _start_thread(self) -> None:
        self._thread = threading.Thread(target=self._reader_loop, name="GloveReaderThread", daemon=True)
        self._thread.start()

    def _reader_loop(self) -> None:
        assert self._ser is not None
        if self.cfg.debug_print:
            print("[GloveReader] Reader thread started.")

        while not self._stop.is_set():
            try:
                line_bytes = self._ser.readline()
            except serial.SerialException as e:
                print(f"[GloveReader] Serial read error: {e}")
                break

            if not line_bytes:
                continue

            line = line_bytes.decode("utf-8", errors="ignore").strip()
            if self.cfg.debug_print:
                print("RAW:", line)

            angles = self._parse_angles_line(line)
            if angles is None:
                continue

            norm_vals = [self._map_angle_to_norm(angles[i], i) for i in range(6)]

            with self._lock:
                self._angles_deg = angles
                self._norm_values = norm_vals
                self._latest_line = line

        if self.cfg.debug_print:
            print("[GloveReader] Reader thread exited.")


class GloveVisualizer:
    def __init__(self, labels: List[str], show_norm: bool = True):
        self.labels = labels
        self.show_norm = show_norm

        plt.ion()
        self.fig, axes = plt.subplots(2, 3, figsize=(10, 6))
        self.axes = axes.flatten()

        self.lines = []
        self.texts = []

        for i, ax in enumerate(self.axes):
            ax.set_aspect("equal")
            ax.set_xlim(-1.2, 1.2)
            ax.set_ylim(-1.2, 1.2)

            circle = plt.Circle((0, 0), 1.0, fill=False, linewidth=2)
            ax.add_patch(circle)

            line, = ax.plot([0, 1], [0, 0], linewidth=3)
            self.lines.append(line)

            ax.set_title(self.labels[i], fontsize=10)
            text = ax.text(0.0, -1.3, "0.00°", ha="center", va="center", fontsize=9)
            self.texts.append(text)

            ax.set_xticks([])
            ax.set_yticks([])

        self.fig.suptitle("Glove 6-Channel Angles", fontsize=14)
        plt.tight_layout()
        plt.show()

    def _update_one(self, i: int, angle_deg: float, norm: Optional[float] = None) -> None:
        theta = math.radians(angle_deg % 360.0)
        x = math.cos(theta)
        y = math.sin(theta)
        self.lines[i].set_data([0, x], [0, y])

        if self.show_norm and norm is not None:
            self.texts[i].set_text(f"{angle_deg:.2f}°  ({norm:.3f})")
        else:
            self.texts[i].set_text(f"{angle_deg:.2f}°")

    def update(self, angles_deg: List[float], norm_vals: Optional[List[float]] = None) -> None:
        for i in range(6):
            n = norm_vals[i] if (norm_vals is not None and i < len(norm_vals)) else None
            self._update_one(i, angles_deg[i], n)
        plt.draw()
        plt.pause(0.001)


def main():
    cfg = GloveConfig(
        port="/dev/ttyACM0",
        baudrate=115200,
        timeout=0.01,
        debug_print=False,
        use_auto_calib=True,
    )

    glove = GloveReader(cfg)
    vis = GloveVisualizer(labels=cfg.channel_labels, show_norm=True)

    print("Receiving glove data. Close window or Ctrl+C to exit.")

    try:
        while plt.fignum_exists(vis.fig.number):
            angles = glove.get_angles_deg()
            norm_vals = glove.get_norm_values()
            vis.update(angles, norm_vals)
            time.sleep(0.01)
    except KeyboardInterrupt:
        pass
    finally:
        glove.close()


if __name__ == "__main__":
    main()
