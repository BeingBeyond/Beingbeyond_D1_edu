from pathlib import Path
import beingbeyond_d1_edu_sdk as _pkg

_ASSETS_DIR = Path(_pkg.__file__).resolve().parent / "BeingBeyond_D1_edu"

def get_default_urdf_path() -> str:
    return str(_ASSETS_DIR / "robot_right_hand.urdf")
