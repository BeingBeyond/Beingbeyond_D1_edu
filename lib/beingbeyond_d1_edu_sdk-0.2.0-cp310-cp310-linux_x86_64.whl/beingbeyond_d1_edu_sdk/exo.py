from dataclasses import dataclass, field
import math
from typing import Callable, Iterator, List, Optional, Sequence, Tuple

from .core._exo_core import (
    ExoCore,
    ExoCoreConfig,
    ExoCoreFrame,
    ExoCoreRead,
)


@dataclass
class ExoDriverCfg:
    """
    Public configuration for the D1 EDU exo reader.

    Only parameters that users normally need to tune are exposed here. Low-level
    serial protocol details stay inside the binary core.
    """

    port: str = "/dev/serial/by-id/usb-1a86_USB2.0-Serial-if00-port0"
    baudrate: int = 115200
    servo_ids: List[int] = field(default_factory=lambda: [1, 2, 3, 4, 5, 6])
    read_hz: float = 10.0
    timeout_s: float = 0.2
    command_delay_s: float = 0.008

    def _to_core_config(self) -> ExoCoreConfig:
        return ExoCoreConfig(
            port=self.port,
            baudrate=self.baudrate,
            servo_ids=list(self.servo_ids),
            timeout_s=self.timeout_s,
            command_delay_s=self.command_delay_s,
            read_hz=self.read_hz,
            clear_input_before_command=True,
        )


@dataclass(frozen=True)
class ExoRead:
    servo_id: int
    raw_pos: Optional[int]
    angle_deg: Optional[float]
    ok: bool
    timestamp_s: float


@dataclass(frozen=True)
class ExoFrame:
    reads: List[ExoRead]
    timestamp_s: float
    elapsed_s: float
    period_s: float
    overrun_s: float

    @property
    def ok(self) -> bool:
        return all(read.ok for read in self.reads)

    @property
    def angles_deg(self) -> List[Optional[float]]:
        return [read.angle_deg for read in self.reads]

    @property
    def raw_positions(self) -> List[Optional[int]]:
        return [read.raw_pos for read in self.reads]


@dataclass(frozen=True)
class ExoChangeIdResult:
    current_id: int
    new_id: int
    verified: bool


class ExoDriver:
    """
    High-level reader for the D1 EDU exo serial device.

    The public API is intentionally small: connect, read joint frames, release
    torque, and run maintenance actions such as servo ID changes. Raw protocol
    command construction is implemented in the compiled core and is not part of
    the stable SDK surface.
    """

    def __init__(self, cfg: Optional[ExoDriverCfg] = None) -> None:
        self.cfg = cfg or ExoDriverCfg()
        self._core = ExoCore(self.cfg._to_core_config())

    @property
    def period_s(self) -> float:
        return self._core.period_s

    @property
    def estimated_min_cycle_s(self) -> float:
        return self._core.estimated_min_cycle_s

    @property
    def estimated_max_hz(self) -> float:
        return self._core.estimated_max_hz

    @property
    def angle_range_deg(self) -> float:
        return self._core.angle_range_deg

    def open(self) -> None:
        self._core.open()

    def close(self) -> None:
        self._core.close()

    def __enter__(self) -> "ExoDriver":
        self.open()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def read_position(self, servo_id: int) -> ExoRead:
        return _convert_read(self._core.read_position(servo_id))

    def read_frame(self) -> ExoFrame:
        return _convert_frame(self._core.read_frame())

    def read_frame_at_rate(self, next_tick_s: float) -> Tuple[ExoFrame, float]:
        frame, next_tick_s = self._core.read_frame_at_rate(next_tick_s)
        return _convert_frame(frame), next_tick_s

    def iter_frames(self, count: Optional[int] = None) -> Iterator[ExoFrame]:
        for frame in self._core.iter_frames(count=count):
            yield _convert_frame(frame)

    def run(
        self,
        callback: Callable[[ExoFrame], None],
        count: Optional[int] = None,
        stop_on_bad_frame: bool = False,
    ) -> None:
        def _callback(frame: ExoCoreFrame) -> None:
            callback(_convert_frame(frame))

        self._core.run(callback=_callback, count=count, stop_on_bad_frame=stop_on_bad_frame)

    def release_torque(self) -> None:
        self._core.release_torque()

    def move_to_midpoint(self, move_time_ms: int = 1000) -> None:
        self._core.move_mid(move_time_ms=move_time_ms)

    def raw_pos_to_angle_deg(self, raw_pos: int) -> float:
        return self._core.raw_pos_to_angle_deg(raw_pos)

    def change_servo_id(self, current_id: int, new_id: int, verify: bool = True) -> ExoChangeIdResult:
        result = self._core.change_servo_id(current_id=current_id, new_id=new_id, verify=verify)
        return ExoChangeIdResult(
            current_id=result.current_id,
            new_id=result.new_id,
            verified=result.verified,
        )


def format_servo_ids(servo_ids: Sequence[int]) -> str:
    return ", ".join(f"{servo_id:03d}" for servo_id in servo_ids)


class ExoDialVisualizer:
    def __init__(
        self,
        servo_ids: Sequence[int],
        angle_range_deg: float = 270.0,
        title: str = "D1 EDU Exo Angles",
    ) -> None:
        import matplotlib.pyplot as plt

        self.plt = plt
        self.servo_ids = list(servo_ids)
        if not self.servo_ids:
            raise ValueError("servo_ids must not be empty")
        self.angle_range_deg = angle_range_deg

        cols = min(3, max(1, len(self.servo_ids)))
        rows = int(math.ceil(len(self.servo_ids) / cols))

        plt.ion()
        self.fig, axes = plt.subplots(
            rows,
            cols,
            figsize=(3.2 * cols, 3.0 * rows),
            subplot_kw={"projection": "polar"},
        )
        if isinstance(axes, list):
            flat_axes = axes
        elif hasattr(axes, "flat"):
            flat_axes = list(axes.flat)
        else:
            flat_axes = [axes]

        self.axes = flat_axes[: len(self.servo_ids)]
        self.lines = []
        self.texts = []

        for ax, servo_id in zip(self.axes, self.servo_ids):
            ax.set_theta_zero_location("N")
            ax.set_theta_direction(-1)
            ax.set_ylim(0.0, 1.0)
            ax.set_yticklabels([])
            ax.set_thetamin(0.0)
            ax.set_thetamax(angle_range_deg)
            ax.set_title(f"ID {servo_id:03d}", fontsize=10)
            line, = ax.plot([0.0, 0.0], [0.0, 0.9], linewidth=3)
            text = ax.text(0.0, 0.15, "--", ha="center", va="center", fontsize=9)
            self.lines.append(line)
            self.texts.append(text)

        for ax in flat_axes[len(self.servo_ids) :]:
            ax.set_visible(False)

        self.fig.suptitle(title, fontsize=14)
        self.fig.tight_layout()
        plt.show(block=False)

    def update(self, frame: ExoFrame) -> bool:
        for line, text, read in zip(self.lines, self.texts, frame.reads):
            if read.angle_deg is None:
                line.set_data([0.0, 0.0], [0.0, 0.0])
                text.set_text("bad")
                continue

            angle_deg = max(0.0, min(self.angle_range_deg, read.angle_deg))
            theta = math.radians(angle_deg)
            line.set_data([theta, theta], [0.0, 0.9])
            text.set_position((theta, 0.15))
            text.set_text(f"{read.angle_deg:.1f} deg")

        self.fig.canvas.draw_idle()
        self.plt.pause(0.001)
        return self.plt.fignum_exists(self.fig.number)


def run_exo_visualizer(
    cfg: Optional[ExoDriverCfg] = None,
    release_torque: bool = True,
) -> None:
    cfg = cfg or ExoDriverCfg()
    with ExoDriver(cfg) as exo:
        if release_torque:
            exo.release_torque()

        visualizer = ExoDialVisualizer(cfg.servo_ids, exo.angle_range_deg)
        for frame in exo.iter_frames():
            if not visualizer.update(frame):
                break


def _convert_read(read: ExoCoreRead) -> ExoRead:
    return ExoRead(
        servo_id=read.servo_id,
        raw_pos=read.raw_pos,
        angle_deg=read.angle_deg,
        ok=read.ok,
        timestamp_s=read.timestamp_s,
    )


def _convert_frame(frame: ExoCoreFrame) -> ExoFrame:
    return ExoFrame(
        reads=[_convert_read(read) for read in frame.reads],
        timestamp_s=frame.timestamp_s,
        elapsed_s=frame.elapsed_s,
        period_s=frame.period_s,
        overrun_s=frame.overrun_s,
    )


__all__ = [
    "ExoDriver",
    "ExoDriverCfg",
    "ExoRead",
    "ExoFrame",
    "ExoChangeIdResult",
    "ExoDialVisualizer",
    "format_servo_ids",
    "run_exo_visualizer",
]


if __name__ == "__main__":
    run_exo_visualizer()
