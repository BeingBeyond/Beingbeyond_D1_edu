from dataclasses import dataclass, field
from typing import Optional, Sequence, Tuple

import numpy as np

from .urdf_path import get_default_urdf_path
from .core._kinematics_core import (
    IKOptions,
    PinocchioKinematicsCore,
    D1KinematicsCore,
    run_ee_teleop_core,
)


@dataclass
class D1KinematicsConfig:
    urdf_path: str = field(default_factory=get_default_urdf_path)
    base_link: str = "link0"
    ee_link: str = "ee"
    camera_link: Optional[str] = "camera"
    head_joint_names: Sequence[str] = (
        "joint_7_head_yaw",
        "joint_8_head_pitch",
    )
    arm_joint_names: Sequence[str] = (
        "joint_1",
        "joint_2",
        "joint_3",
        "joint_4",
        "joint_5",
        "joint_6",
    )


class D1Kinematics:
    def __init__(self, config: D1KinematicsConfig= None) -> None:
        if config is None:
            config = D1KinematicsConfig()
        self.config = config

        self._core = D1KinematicsCore(
            urdf_path=config.urdf_path,
            base_link=config.base_link,
            ee_link=config.ee_link,
            camera_link=config.camera_link,
            head_joint_names=config.head_joint_names,
            arm_joint_names=config.arm_joint_names,
        )

        self._kin: PinocchioKinematicsCore = self._core.kin
        self.nq = self._kin.nq
        self.nv = self._kin.nv

    @property
    def head_joint_names(self) -> Sequence[str]:
        return self._core.head_joint_names

    @property
    def arm_joint_names(self) -> Sequence[str]:
        return self._core.arm_joint_names

    def make_q(self, q_head: np.ndarray, q_arm: np.ndarray) -> np.ndarray:
        return self._core.make_q(q_head, q_arm)

    def split_q(self, q: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        q = np.asarray(q, dtype=float).reshape(-1)
        n_head = len(self.head_joint_names)
        n_arm = len(self.arm_joint_names)
        n_headarm = n_head + n_arm

        # Hardware APIs return the compact head+arm vector in joint order:
        # [head_yaw, head_pitch, arm_1, ..., arm_6]. Accept that form here
        # because examples often pass robot.get_positions() directly.
        if q.shape[0] == n_headarm:
            return q[:n_head].copy(), q[n_head:].copy()

        return self._core.split_q(q)


    def ee_in_base(self, q_head: np.ndarray, q_arm: np.ndarray) -> np.ndarray:
        return self._core.ee_in_base(q_head, q_arm)

    def camera_in_base(self, q_head: np.ndarray, q_arm: np.ndarray) -> np.ndarray:
        return self._core.camera_in_base(q_head, q_arm)


    def ik_T_ee_with_arm_only(
        self,
        target_T_base_ee: np.ndarray,
        q_head: np.ndarray,
        q_arm_init: np.ndarray,
        options: Optional[IKOptions] = None,
    ) -> Tuple[np.ndarray, np.ndarray, float, int]:
        return self._core.ik_T_ee_with_arm_only(
            target_T_base_ee=target_T_base_ee,
            q_head=q_head,
            q_arm_init=q_arm_init,
            options=options,
        )

    def ik_ee_quatpose_with_arm_only(
        self,
        target_ee_quatpose: np.ndarray,
        q_head: np.ndarray,
        q_arm_init: np.ndarray,
        options: Optional[IKOptions] = None,
    ) -> Tuple[np.ndarray, np.ndarray, float, int]:
        return self._core.ik_ee_quatpose_with_arm_only(
            target_quatpose_base_ee=target_ee_quatpose,
            q_head=q_head,
            q_arm_init=q_arm_init,
            options=options,
        )


def run_ee_teleop(
    config: D1KinematicsConfig = None,
    use_viz: bool = True,
) -> None:
    if config is None:
        config = D1KinematicsConfig()

    run_ee_teleop_core(
        urdf_path=config.urdf_path,
        base_link=config.base_link,
        ee_link=config.ee_link,
        camera_link=config.camera_link,
        head_joint_names=config.head_joint_names,
        arm_joint_names=config.arm_joint_names,
        use_viz=use_viz,
    )


if __name__ == "__main__":

    cfg = D1KinematicsConfig()
    run_ee_teleop(cfg, use_viz=True)
