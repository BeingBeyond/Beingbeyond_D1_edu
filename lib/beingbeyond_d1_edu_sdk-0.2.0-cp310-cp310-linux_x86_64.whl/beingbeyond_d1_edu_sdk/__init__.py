__version__ = "0.2.0"

__all__ = [
    "HeadArmRobot",
    "deg_list_to_rad",
    "rad_list_to_deg",
    "get_default_urdf_path",
    "ExoDriver",
    "ExoDriverCfg",
    "ExoRead",
    "ExoFrame",
    "ExoChangeIdResult",
    "ExoDialVisualizer",
    "run_exo_visualizer",
]


def __getattr__(name):
    if name in {"HeadArmRobot", "deg_list_to_rad", "rad_list_to_deg"}:
        from .head_arm import HeadArmRobot, deg_list_to_rad, rad_list_to_deg

        values = {
            "HeadArmRobot": HeadArmRobot,
            "deg_list_to_rad": deg_list_to_rad,
            "rad_list_to_deg": rad_list_to_deg,
        }
        return values[name]
    if name == "get_default_urdf_path":
        from .urdf_path import get_default_urdf_path

        return get_default_urdf_path
    if name in {
        "ExoDriver",
        "ExoDriverCfg",
        "ExoRead",
        "ExoFrame",
        "ExoChangeIdResult",
        "ExoDialVisualizer",
        "run_exo_visualizer",
    }:
        from .exo import (
            ExoChangeIdResult,
            ExoDialVisualizer,
            ExoDriver,
            ExoDriverCfg,
            ExoFrame,
            ExoRead,
            run_exo_visualizer,
        )

        values = {
            "ExoDriver": ExoDriver,
            "ExoDriverCfg": ExoDriverCfg,
            "ExoRead": ExoRead,
            "ExoFrame": ExoFrame,
            "ExoChangeIdResult": ExoChangeIdResult,
            "ExoDialVisualizer": ExoDialVisualizer,
            "run_exo_visualizer": run_exo_visualizer,
        }
        return values[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
